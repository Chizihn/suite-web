import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useBookingStore } from "../store/bookingStore";
import type { Booking } from "../types";
import { Button } from "../components/ui/Button";
import BookingCard from "../components/ui/BookingCard";

type TabType = "upcoming" | "past" | "saved";

interface EmptyStateConfig {
  title: string;
  description: string;
  image?: string | null;
}

const getEmptyStateConfigs = (): Record<TabType, EmptyStateConfig> => ({
  upcoming: {
    title: "No bookings yet",
    description:
      "You don't have any bookings yet. Start exploring hotels and make your first booking!",
    image: "/booking-1.png",
  },
  past: {
    title: "No bookings yet",
    description: "Start exploring hotels and make your first booking",
    image: null,
  },
  saved: {
    title: "No bookings saved",
    description: "Save your favorite bookings to view them here",
    image: null,
  },
});

const Bookings: React.FC = () => {
  const { bookings, savedBookings, fetchBookings } = useBookingStore();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>("upcoming");

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleClickBooking = (id: string) => {
    navigate(`/booking/${id}`);
  };

  const getFilteredBookings = (): Booking[] => {
    switch (activeTab) {
      case "upcoming":
      case "past":
        return bookings;
      case "saved":
        return savedBookings || [];
      default:
        return bookings;
    }
  };

  const filteredBookings = getFilteredBookings();
  const emptyStateConfigs = getEmptyStateConfigs();

  return (
    <div className="p-4">
      <h2 className="text-h4 font-semibold mb-6">Bookings</h2>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {(["upcoming", "past", "saved"] as TabType[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 text-center rounded-sm text-body1 font-medium ${
              activeTab === tab
                ? "bg-primary text-text-inverse"
                : "text-text-secondary"
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Bookings or Empty State */}
      {filteredBookings.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-[50vh]">
          <EmptyState
            config={emptyStateConfigs[activeTab]}
            onExplore={() => navigate("/hotels")}
          />
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {filteredBookings.map((booking) => (
            <BookingCard
              key={booking.id}
              booking={booking}
              onClick={() => handleClickBooking(booking.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const EmptyState: React.FC<{
  config: EmptyStateConfig;
  onExplore: () => void;
}> = ({ config, onExplore }) => {
  return (
    <div className="text-center px-6">
      {config.image && (
        <img
          src={config.image}
          alt="Empty"
          className="mx-auto mb-4 w-48 h-48 object-contain"
        />
      )}
      <h3 className="text-xl font-semibold mb-2">{config.title}</h3>
      <p className="text-gray-500 mb-4">{config.description}</p>
      <Button onClick={onExplore}>Explore Hotels</Button>
    </div>
  );
};

export default Bookings;
