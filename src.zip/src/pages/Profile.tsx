import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Wallet, Bell, HelpCircle, Mail, LogOut, User, ChevronRight } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

// Reset body styles
document.body.className = 'bg-background-primary min-h-screen';

interface ProfileItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick?: () => void;
  isDanger?: boolean;
}

interface ProfileItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick?: () => void;
  isDanger?: boolean;
  isLast?: boolean;
}

const ProfileItem: React.FC<ProfileItemProps> = ({ 
  icon, 
  title, 
  description, 
  onClick, 
  isDanger = false,
  isLast = false
}) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full p-4 text-left transition-all duration-200 font-sans ${
      isDanger 
        ? 'hover:bg-error/10 hover:translate-x-1' 
        : 'hover:bg-surface-secondary/50 active:bg-surface-secondary/70 hover:translate-x-1'
    } ${!isLast ? 'border-b border-border-primary' : ''}`}
    aria-label={title}
  >
    <div className="flex items-center gap-4 w-full group">
      <div className={`p-2 rounded-lg transition-colors ${
        isDanger 
          ? 'bg-error/10 text-error group-hover:bg-error/20' 
          : 'bg-surface-tertiary/50 text-text-secondary group-hover:bg-surface-tertiary/70'
      }`}>
        {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { 
          className: 'w-4.5 h-4.5' 
        }) : icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium truncate transition-colors ${
          isDanger 
            ? 'text-error group-hover:text-error/90' 
            : 'text-text-primary group-hover:text-primary'
        }`}>
          {title}
        </p>
        <p className="text-xs text-text-tertiary truncate group-hover:text-text-secondary transition-colors">
          {description}
        </p>
      </div>
      <ChevronRight 
        size={16} 
        className={`flex-shrink-0 transition-transform group-hover:translate-x-1 ${
          isDanger 
            ? 'text-error/70 group-hover:text-error' 
            : 'text-text-tertiary group-hover:text-primary'
        }`} 
      />
    </div>
  </button>
);

const Profile: React.FC = () => {
  const { user, disconnect } = useAuthStore();
  const navigate = useNavigate();

  const handleDisconnect = () => {
    disconnect();
    navigate('/connect-wallet');
  };

  const handleNavigate = (route: string) => {
    navigate(route);
  };

  const profileSections = [
    {
      title: 'Account',
      items: [
        {
          icon: <User size={18} />,
          title: 'My Profile',
          description: 'View and edit your profile information',
          onClick: () => handleNavigate('/profile/edit'),
        },
        {
          icon: <Wallet size={18} />,
          title: 'Payment Methods',
          description: 'Manage your wallet and payment preferences',
          onClick: () => handleNavigate('/profile/wallet'),
        },
        {
          icon: <Bell size={18} />,
          title: 'Notifications',
          description: 'Configure your notification preferences',
          onClick: () => handleNavigate('/profile/notifications'),
        },
        {
          icon: <Settings size={18} />,
          title: 'Settings',
          description: 'Customize your app preferences',
          onClick: () => handleNavigate('/profile/settings'),
        },
      ],
    },
    {
      title: 'Support',
      items: [
        {
          icon: <HelpCircle size={18} />,
          title: 'Help Center',
          description: 'Get help with your bookings and account',
          onClick: () => handleNavigate('/profile/help'),
        },
        {
          icon: <Mail size={18} />,
          title: 'Contact Us',
          description: 'Reach out to our support team',
          onClick: () => handleNavigate('/profile/contact'),
        },
      ],
    },
    {
      title: 'Account',
      items: [
        {
          icon: <LogOut size={18} />,
          title: 'Log Out',
          description: 'Sign out of your account',
          onClick: handleDisconnect,
          isDanger: true,
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen p-4 bg-background-primary font-sans">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Profile Header */}
        <div className="text-center">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-surface-primary flex items-center justify-center overflow-hidden">
            {/* {user?.avatar ? (
              <img 
                src={user.avatar} 
                alt={user.address || 'User'}
                className="w-full h-full object-cover"
              />
            ) : (
              <User size={40} className="text-text-tertiary" />
            )} */}
              <User size={40} className="text-text-tertiary" />

          </div>
          <h1 className="text-2xl font-bold text-text-primary mb-1">
            {user?.address || 'Anonymous User'}
          </h1>
          {/* <p className="text-text-tertiary mb-3">
            {user?.email || 'Connected with Web3'}
          </p> */}
          {user?.address && (
            <div className="inline-flex items-center px-3 py-1.5 bg-surface-secondary rounded-full">
              <span className="text-xs font-mono text-text-secondary">
                {`${user.address.slice(0, 6)}...${user.address.slice(-4)}`}
              </span>
            </div>
          )}
        </div>

        {/* Profile Sections */}
        <div className="space-y-4">
          {profileSections.map((section, index) => (
            <div key={index} className="space-y-2">
              <h2 className="text-xs font-semibold text-text-tertiary px-2">
                {section.title.toUpperCase()}
              </h2>
              <div className="bg-surface-primary rounded-lg overflow-hidden">
                {section.items.map((item, itemIndex) => (
                  <ProfileItem
                    key={itemIndex}
                    icon={item.icon}
                    title={item.title}
                    description={item.description}
                    onClick={item.onClick}
                    // isDanger={item.isDanger}
                    isLast={itemIndex === section.items.length - 1}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Profile;