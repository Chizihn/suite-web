import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Map, AlertCircle, RefreshCcw, Frown, SlidersHorizontal } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';
import { useHotelStore } from '../store/hotelStore';
import SearchInput from '../components/ui/SearchInput';

const PRICE_OPTIONS = ["Any", "$", "$$", "$$$"];
const AMENITIES = ["Pool", "Free WiFi", "Parking", "Pet-Friendly", "Spa", "Restaurant", "Beach Access"];


interface Hotel {
  id: string;
  name: string;
  price: number;
  amenities: string[];
  images: string[];
}

const Hotels: React.FC = () => {
  const {
    hotels,
    loading: hotelsLoading,
    error: hotelsError,
  } = useHotelStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<"list" | "map">("list");
  const [filterModal, setFilterModal] = useState(false);
  const [search, setSearch] = useState("");
  const [appliedSearch, setAppliedSearch] = useState("");
  const [appliedPrice, setAppliedPrice] = useState<string>("Any");
  const [appliedAmenities, setAppliedAmenities] = useState<string[]>([]);
  const [modalPrice, setModalPrice] = useState<string>("Any");
  const [modalAmenities, setModalAmenities] = useState<string[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  // Extract query params for initial filter state
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const category = params.get("category");
    const deal = params.get("deal");
    const amenity = params.get("amenity");
    if (category) setAppliedSearch(category);
    if (deal) setAppliedSearch(deal);
    if (amenity) setAppliedAmenities([amenity]);
  }, [location.search]);

  // Filter hotels
  const filteredHotels = hotels.filter((hotel) => {
    const matchesSearch =
      !appliedSearch ||
      hotel.name.toLowerCase().includes(appliedSearch.toLowerCase());
    let matchesPrice = true;
    if (appliedPrice !== "Any") {
      if (appliedPrice === "Low") matchesPrice = hotel.price <= 150;
      if (appliedPrice === "Medium")
        matchesPrice = hotel.price > 150 && hotel.price <= 350;
      if (appliedPrice === "High") matchesPrice = hotel.price > 350;
    }
    const matchesAmenities =
      appliedAmenities.length === 0 ||
      appliedAmenities.every((a) => hotel.amenities.includes(a));
    return matchesSearch && matchesPrice && matchesAmenities;
  });

  const getDistance = (hotel: Hotel) => {
    if (hotel.id === "1") return "1.2 miles from SuiCon";
    if (hotel.id === "2") return "1.5 miles from SuiCon";
    if (hotel.id === "3") return "2.0 miles from SuiCon";
    return "1.0 miles from SuiCon";
  };

  const handleSearch = () => {
    setSearchLoading(true);
    setTimeout(() => {
      setAppliedSearch(search);
      setSearchLoading(false);
    }, 800);
  };

  const handleApplyFilters = () => {
    setSearchLoading(true);
    setTimeout(() => {
      setAppliedPrice(modalPrice);
      setAppliedAmenities(modalAmenities);
      setFilterModal(false);
      setSearchLoading(false);
    }, 800);
  };

  const openFilterModal = () => {
    setModalPrice(appliedPrice);
    setModalAmenities(appliedAmenities);
    setFilterModal(true);
  };

  //   const handleRefresh = () => {
  //     refetch();
  //   };

  const handleHotelClick = (hotel: Hotel) => {
    navigate(`/hotels/${hotel.id}`);
  };

  // Loading state
  if (hotelsLoading && hotels.length === 0) {
    return (
      <div className="min-h-screen bg-background-primary">
        <div className="sticky top-0 z-10 bg-background-primary border-b border-border-primary/30 p-4">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl font-bold text-text-primary">Hotels</h1>
            <p className="text-sm text-text-secondary">Find your perfect stay</p>
          </div>
        </div>
        <div className="max-w-6xl mx-auto p-4">
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex p-4 bg-surface-primary rounded-xl">
                <div className="w-24 h-24 bg-surface-secondary rounded-lg mr-4"></div>
                <div className="flex-1">
                  <div className="h-5 bg-surface-secondary rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-surface-secondary rounded w-1/2 mb-2"></div>
                  <div className="h-4 bg-surface-secondary rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (hotelsError) {
    return (
      <div className="min-h-screen bg-background-primary p-4 flex items-center justify-center">
        <div className="max-w-md text-center p-6 bg-surface-primary rounded-xl">
          <div className="flex justify-center mb-4">
            <AlertCircle size={48} className="text-error" />
          </div>
          <h2 className="text-xl font-bold text-text-primary mb-2">Error Loading Hotels</h2>
          <p className="text-sm text-text-secondary mb-6">
            {hotelsError}
          </p>
          <Button
            variant="primary"
            onClick={() => window.location.reload()}
            className="w-full flex items-center justify-center gap-2"
          >
            <RefreshCcw size={16} />
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background-primary">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background-primary border-b border-border-primary/30 p-4">
        <div className="max-w-6xl mx-auto space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-text-primary">Hotels</h1>
              <p className="text-sm text-text-secondary">Find your perfect stay</p>
            </div>
            {user && (
              <div className="text-xs bg-surface-secondary px-3 py-1.5 rounded-full text-text-secondary">
                {user.address.slice(0, 6)}...{user.address.slice(-4)}
              </div>
            )}
          </div>

          {/* Search Bar */}
          <div className="relative">
            <SearchInput
              placeholder="Search hotels, locations, or amenities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="w-full"
              inputClassName="pl-12 pr-6"
            />
            <button 
              onClick={openFilterModal}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-tertiary hover:text-text-secondary"
            >
              <SlidersHorizontal size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-6xl mx-auto px-4 pt-2">
        <div className="inline-flex bg-surface-primary rounded-lg p-1">
          {['list', 'map'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as 'list' | 'map')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                activeTab === tab
                  ? 'bg-white text-text-primary shadow-sm'
                  : 'text-text-tertiary hover:text-text-secondary'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-4">
        {/* Loading Bar */}
        {(searchLoading || hotelsLoading) && (
          <div className="mb-6">
            <div className="h-1 bg-surface-secondary rounded-full overflow-hidden">
              <div className="h-full bg-primary/80 animate-pulse w-1/3"></div>
            </div>
            <p className="mt-2 text-sm text-text-tertiary text-center">
              {hotelsLoading ? 'Loading hotels...' : 'Finding your perfect stay...'}
            </p>
          </div>
        )}

        {/* Content */}
        {activeTab === 'list' ? (
          <div className="space-y-4">
            {filteredHotels.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 bg-surface-primary rounded-xl">
                <Frown size={48} className="text-text-tertiary mb-4" />
                <h3 className="text-lg font-medium text-text-primary mb-1">No hotels found</h3>
                <p className="text-sm text-text-secondary text-center max-w-md px-4">
                  We couldn't find any hotels matching your search. Try adjusting your filters or search terms.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-4">
                {filteredHotels.map((hotel) => (
                  <button
                    key={hotel.id}
                    onClick={() => handleHotelClick(hotel)}
                    className="group flex items-start bg-surface-primary hover:bg-surface-secondary rounded-xl p-4 transition-colors text-left w-full"
                  >
                    <div className="relative w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden mr-4">
                      <img
                        src={hotel.images[0] || '/placeholder.svg'}
                        alt={hotel.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {Math.floor(Math.random() * 2) + 4}.{Math.floor(Math.random() * 9)} ★
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h3 className="text-base font-semibold text-text-primary truncate">
                          {hotel.name}
                        </h3>
                        <div className="flex items-center bg-surface-secondary px-2 py-1 rounded-full ml-2">
                          <span className="text-sm font-medium text-primary">{hotel.price}</span>
                          <span className="text-xs text-text-tertiary ml-1">$SUI</span>
                        </div>
                      </div>
                      <p className="text-sm text-text-secondary mt-1">{getDistance(hotel)}</p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {hotel.amenities.slice(0, 3).map((amenity) => (
                          <span key={amenity} className="text-xs bg-surface-tertiary text-text-tertiary px-2 py-1 rounded">
                            {amenity}
                          </span>
                        ))}
                        {hotel.amenities.length > 3 && (
                          <span className="text-xs text-text-tertiary">+{hotel.amenities.length - 3} more</span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 bg-surface-primary rounded-xl">
            <Map size={48} className="text-text-tertiary mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-1">Map View Coming Soon</h3>
            <p className="text-sm text-text-secondary max-w-sm text-center">
              We're working on bringing you an interactive map to help you find hotels near your destination.
            </p>
          </div>
        )}
      </div>

      {/* Filter Modal */}
      <Modal
        isOpen={filterModal}
        title="Filter Hotels"
        onClose={() => setFilterModal(false)}
      >
        <div className="max-w-md">
        <div className="space-y-6 py-2">
          {/* Price Filter */}
          <div>
            <h3 className="text-sm font-medium text-text-primary mb-3">Price Range</h3>
            <div className="grid grid-cols-4 gap-2">
              {PRICE_OPTIONS.map((price) => (
                <button
                  key={price}
                  onClick={() => setModalPrice(price)}
                  className={`py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    modalPrice === price
                      ? 'bg-primary text-black'
                      : 'bg-surface-secondary text-text-primary hover:bg-surface-tertiary'
                  }`}
                >
                  {price}
                </button>
              ))}
            </div>
          </div>

          {/* Amenities Filter */}
          <div>
            <h3 className="text-sm font-medium text-text-primary mb-3">Amenities</h3>
            <div className="grid grid-cols-2 gap-2">
              {AMENITIES.map((amenity) => (
                <button
                  key={amenity}
                  onClick={() =>
                    setModalAmenities(
                      modalAmenities.includes(amenity)
                        ? modalAmenities.filter((a) => a !== amenity)
                        : [...modalAmenities, amenity]
                    )
                  }
                  className={`flex items-center py-2 px-3 rounded-lg text-sm transition-colors ${
                    modalAmenities.includes(amenity)
                      ? 'bg-primary/10 text-primary border border-primary/20'
                      : 'bg-surface-secondary text-text-primary hover:bg-surface-tertiary border border-transparent'
                  }`}
                >
                  <span className="flex-1 text-left">{amenity}</span>
                  <div className={`w-4 h-4 rounded-sm border ${
                    modalAmenities.includes(amenity)
                      ? 'bg-primary border-primary flex items-center justify-center'
                      : 'border-border-primary'
                  }`}>
                    {modalAmenities.includes(amenity) && (
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20 6L9 17L4 12" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              onClick={() => {
                setModalPrice('Any');
                setModalAmenities([]);
              }}
              className="flex-1"
            >
              Reset
            </Button>
            <Button
              onClick={handleApplyFilters}
              className="flex-1"
              disabled={searchLoading}
            >
              {searchLoading ? 'Applying...' : 'Show Results'}
            </Button>
          </div>
        </div>
        </div>
      </Modal>
    </div>
  );
};

export default Hotels;
