// Header.tsx
import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Wallet, LogOut, Home, Search, Book, Hotel, User } from 'lucide-react';
import { useSuiWallet } from '../hooks/useSuiWallet';

const Header: React.FC = () => {
  const { isConnected, address, walletName, wallets, disconnect } = useSuiWallet();
  const [isScrolled, setIsScrolled] = useState(false);
  const [showWalletMenu, setShowWalletMenu] = useState(false);
  const navigate = useNavigate();

  // Handle scroll effect for header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { to: '/', label: 'Dashboard', icon: <Home size={20} /> },
    { to: '/explore', label: 'Explore', icon: <Search size={20} /> },
    { to: '/bookings', label: 'Bookings', icon: <Book size={20} /> },
    { to: '/hotels', label: 'Hotels', icon: <Hotel size={20} /> },
    { to: '/profile', label: 'Profile', icon: <User size={20} /> },
  ];

  const handleDisconnect = async () => {
    try {
      await disconnect();
      setShowWalletMenu(false);
    } catch (error) {
      console.error('Failed to disconnect wallet:', error);
    }
  };

  return (
    <header 
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-background-primary/95 backdrop-blur-lg  py-2 shadow-lg' 
          : 'bg-background-primary/5 backdrop-blur-lg py-3'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <NavLink to="/" className="flex items-center">
              <h2 className="text-2xl font-bold text-white">Sui.te</h2>
            </NavLink>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                    isActive 
                      ? 'bg-primary/10 text-primary' 
                      : 'text-gray-300 hover:text-white hover:bg-surface-secondary/50'
                  }`
                }
              >
                {link.icon}
                <span>{link.label}</span>
              </NavLink>
            ))}
          </nav>

          {/* Wallet Section */}
          <div className="relative flex items-center">
            {isConnected && address ? (
              <div className="relative">
                <button
                  onClick={() => setShowWalletMenu(!showWalletMenu)}
                  className="flex items-center gap-2 bg-surface-primary border border-border-primary rounded-full px-3 py-1.5 hover:bg-surface-secondary transition-colors"
                  aria-label="Wallet menu"
                >
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <Wallet size={16} className="text-primary" />
                  </div>
                  <span className="text-sm font-medium text-white">
                    {`${address.slice(0, 6)}...${address.slice(-4)}`}
                  </span>
                </button>

                {/* Wallet Dropdown Menu */}
                {showWalletMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-surface-primary rounded-lg shadow-lg border border-border-primary z-50">
                    <div className="p-3 border-b border-border-primary">
                      <p className="text-sm text-text-secondary">Connected with {walletName}</p>
                      <p className="text-sm font-medium text-white truncate">{address}</p>
                    </div>
                    <div className="p-1">
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(address);
                          setShowWalletMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 text-sm text-text-primary hover:bg-surface-secondary rounded-md transition-colors"
                      >
                        Copy Address
                      </button>
                      <button
                        onClick={handleDisconnect}
                        className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-surface-secondary rounded-md transition-colors flex items-center gap-2"
                      >
                        <LogOut size={16} />
                        <span>Disconnect</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setShowWalletMenu(!showWalletMenu)}
                  className="bg-gradient-to-r from-primary to-primary-dark text-white px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 hover:shadow-lg hover:shadow-primary/20 transition-all"
                >
                  <Wallet size={16} />
                  <span>Connect Wallet</span>
                </button>

                {/* Wallet Selection Menu */}
                {showWalletMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-surface-primary rounded-lg shadow-lg border border-border-primary z-50">
                    <div className="p-3 border-b border-border-primary">
                      <h3 className="text-sm font-medium text-white">Select a wallet</h3>
                    </div>
                    <div className="p-2 space-y-1">
                      {wallets.map((wallet) => (
                        <button
                          key={wallet.name}
                          onClick={() => {
                            // The actual connection is handled by the wallet's UI
                            setShowWalletMenu(false);
                            navigate('/profile');
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 text-sm text-text-primary hover:bg-surface-secondary rounded-md transition-colors"
                        >
                          {wallet.icon && (
                            <img 
                              src={wallet.icon} 
                              alt={wallet.name}
                              className="w-5 h-5"
                            />
                          )}
                          <span>{wallet.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Click outside to close menu */}
            {showWalletMenu && (
              <div 
                className="fixed inset-0 z-40"
                onClick={() => setShowWalletMenu(false)}
              />
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;