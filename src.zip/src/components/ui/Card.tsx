export interface CardProps {
  children: React.ReactNode;
  variant?: "default" | "elevated" | "outlined";
  className?: string;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = "default",
  className = "",
}) => {
  const base = "rounded-md p-4";
  const variants = {
    default: "bg-white border border-gray-200",
    elevated: "bg-white shadow-md",
    outlined: "border border-gray-300 bg-transparent",
  };

  return (
    <div className={`${base} ${variants[variant]} ${className}`}>
      {children}
    </div>
  );
};
