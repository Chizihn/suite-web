import React from 'react';
import { Search } from 'lucide-react';

interface SearchInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  variant?: 'default' | 'filled' | 'outline';
  inputSize?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  containerClassName?: string;
  inputClassName?: string;
}

const SearchInput: React.FC<SearchInputProps> = ({
  variant = 'default',
  inputSize = 'md',
  fullWidth = true,
  containerClassName = '',
  inputClassName = '',
  className,
  ...props
}) => {
  // Variant styles
  const variantStyles = {
    default: 'bg-surface-primary border border-border-primary/30 focus:border-primary/50',
    filled: 'bg-surface-secondary border border-transparent focus:border-primary/30',
    outline: 'bg-transparent border border-border-primary/50 focus:border-primary/50',
  };

  // Size styles
  const sizeStyles = {
    sm: 'h-9 px-3 text-sm',
    md: 'h-11 px-4 text-sm',
    lg: 'h-14 px-5 text-base',
  } as const;

  // Icon sizes
  const iconSizes = {
    sm: 16,
    md: 18,
    lg: 20,
  } as const;

  return (
    <div className={`relative ${fullWidth ? 'w-full' : 'w-auto'} ${containerClassName}`}>
      <Search
        size={iconSizes[inputSize]}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 text-text-tertiary pointer-events-none"
      />
      <input
        type="text"
        className={`w-full bg-primary text-text-primary placeholder-text-tertiary/70 
                  focus:outline-none transition-all duration-200 font-inherit
                  ${variantStyles[variant]} ${sizeStyles[inputSize]} 
                  ${fullWidth ? 'w-full' : 'w-auto'} 
                  pl-20 pr-4 rounded-lg ${inputClassName}`}
        {...props}
      />
    </div>
  );
};

export default SearchInput;
